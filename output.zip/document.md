Oracle Cloud Infrastructure 2025 Certified Generative AI Professional (Certificate); Fundamentals of Machine Learning with Scikit-learn
(Infosys Springboard) (Certificate); Python Programming 04 (Infosys Springboard); Oracle Cloud Infrastructure 2025 Certified Data
Science Professional (Certificate)

– Directed a 4-member engineering group to construct the Dream Job Finder application; validated UX with 200+ user tests to refine
discovery workflows.

– Built a regex-driven normalization pipeline with pandas to remove noisy artifacts and formatting inconsistencies, reducing noise by 85%.

– Containerized the FastAPI inference service and automated CI/CD via GitHub Actions, reducing deployment latency to 5 minutes.
– Evaluated transformer and classical NLP architectures through a modular experimentation framework, achieving accuracy improve-
ments of up to 12%.

– Engineered 10+ modular React components and reusable UI primitives, accelerating frontend composition by 30%.

– Processed 20,000+ WhatsApp messages to extract temporal engagement patterns, behavioral indicators, and chat dynamics.

Engineered an end-to-end MLOps workflow (ingestion $\rightarrow$ preprocessing $\rightarrow$ training $\rightarrow$ evaluation), reducing manual orchestration by
70%.

– Orchestrated dataset and model lineage with DVC and AWS S3 remote, guaranteeing complete experiment reproducibility.

## INTERNSHIP EXPERIENCE

## PROJECTS

– Optimized RESTful API consumption and client-side caching patterns, increasing perceived responsiveness and reliability by 20%.

– Conducted weekly code reviews and paired programming to enforce code quality, testing discipline, and sprint completion.

## EDUCATION

March 2024 – April 2024

Frontend Developer Intern | Team Lead

## SKILLS

WhatsApp Chat Analyzer (GitHub)

- Programming: Python, C++,JavaScript(basics), SQL, C
- Web & Datastores: HTML, CSS, Node.js (basics), Streamlit, MongoDB
- Cloud & DevOps: AWS (fundamentals), Docker, GitHub Actions, ECR, EC2
- Libraries & Tooling: scikit-learn, pandas, NumPy, Matplotlib, MLflow, Grafana, Git,langchain,langgraph(basics)
- Concepts & Practices: Algorithmic design, Machine Learning, Deep Learning, Object-Oriented Design, MLOps pipelines,
- CI/CD automation, Model Serving

November 2025 – Ongoing

October 2025 – Present

– Solved 125+ GeeksforGeeks problems with a sustained practice cadence to improve pattern recognition and solution design.

July 2025 – August 2025

- – Developed an **Agentic AI chatbot** using LangGraph with state-based execution for controlled multi-step conversation flow.
- – Implemented a **Resume Chat feature** allowing users to query and interact with resume data through structured agent workflows.
- – Integrated **SQLite** for persistent storage of conversation state, user sessions, and chat history.
- – Enabled **real-time streaming responses** from the LLM, improving user experience and perceived latency.

Solved 500+ LeetCode problems (top 15% globally), demonstrating algorithmic reasoning and data-structure fluency.

## ACHIEVEMENTS

Sentiment Analysis Using MLOps (GitHub)

Agentic AI Chatbot using LangGraph (GitHub)

## IBM

## CERTIFICATIONS

– Synthesized analytical visualizations with Matplotlib, highlighting peak activity windows, emoji distributions, and temporal trends.
– Compiled an interactive insights dossier that surfaced activity bursts, sentiment signals, and conversational flow metrics.

<table>
<tbody>
<tr>
<td>Ajay Kumar Garg Engineering College, Ghaziabad<br/>B.Tech in Information Technology, CGPA: 8.59</td>
<td>2022 – 2026<br/>Top 5% of the Branch</td>
</tr>
<tr>
<td>Kusum Devi Saraswati Vidya Mandir SherpurBalla, Bijnor<br/>Class XII (UP Board), Percentage: 89%</td>
<td>2020 – 2022<br/>PCM</td>
</tr>
<tr>
<td>Kusum Devi Saraswati Vidya Mandir SherpurBalla, Bijnor<br/>Class X (UP Board), Percentage: 85.5%</td>
<td>2018 – 2020</td>
</tr>
</tbody>
</table>

LUCKY CHAUHAN
Bijnor, Uttar Pradesh
luckymilak243@gmail.com | +91-7300541487 | LinkedIn | GitHub | LeetCode | GeeksforGeeks